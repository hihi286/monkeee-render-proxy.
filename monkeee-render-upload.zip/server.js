const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const UPSTREAM = 'https://monkeee-chenjen.laviewddns.com';
const PORT = process.env.PORT || 10000;

app.disable('x-powered-by');

const proxy = createProxyMiddleware({
  target: UPSTREAM,
  changeOrigin: true,
  ws: true,
  autoRewrite: true,
  cookieDomainRewrite: '',
  on: {
    error: (err, req, res) => {
      console.error('Upstream proxy error:', err.message);
      if (typeof res.writeHead === 'function' && !res.headersSent) {
        res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Could not reach the original game website.');
      }
    }
  }
});

app.use(proxy);

const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`Proxy listening on port ${PORT}; upstream: ${UPSTREAM}`);
});

// Forward game connections that use WebSockets.
server.on('upgrade', proxy.upgrade);
